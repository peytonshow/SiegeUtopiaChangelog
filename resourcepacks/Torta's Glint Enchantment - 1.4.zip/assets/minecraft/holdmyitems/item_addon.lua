local item = context.item
local particles = context.particles
local hand = context.hand

if I:isEnchanted(item) then
    particleManager:addParticle(particles,
        false,
        0.09,
        0.3,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        2.5,
        Texture:of("minecraft", "textures/particle/swordglow.png"), "ITEM", hand, "SPAWN", "ADDITIVE", 0, 255)
end
