local player = context.player
local item = context.item
local matrices = context.matrices
local mainHand = context.mainHand
local blockBreaking = context.blockBreaking
local progress = context.swingProgress
local hitAnim
global.breakAnimation = 0;

if blockBreaking then
    breakAnimation = breakAnimation + 0.018
else
    breakAnimation = breakAnimation * 0.99
end

if progress < 0.7 and not blockBreaking then
    hitAnim = M:sin(M:clamp(progress, 0, 0.3) * 5)
else
    hitAnim = M:sin(M:clamp(progress, 0.7, 1) * 5 - 2)
end

if not blockBreaking and I:isIn(item, Tags:getVanillaTag("pickaxes")) and progress > 0 then
    M:rotateZ(matrices, -40 * hitAnim)
end

local A = 30 + 10 * M:abs(M:sin(breakAnimation / 2))
local B = 4
local C = 3

local mainSwing = A * M:sin(breakAnimation) * M:abs(M:sin(breakAnimation))
local microSwing = B * M:sin(breakAnimation * 0.5)
local sway = C * M:sin(breakAnimation / 4)

local angle = mainSwing + microSwing

if mainHand then
    if blockBreaking and I:isIn(item, Tags:getVanillaTag("pickaxes")) then
        M:rotateZ(matrices, angle / 2.5)
        M:rotateZ(matrices, -angle /1.2)
    else
    A = 0
    B = 0
    C = 0
    mainSwing = 0
    microSwing = 0
    sway = 0
    angle = 0
    end
end