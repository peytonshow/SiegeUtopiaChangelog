local bl = context.bl
local item = context.item
local matrices = context.matrices
local player = context.player
local mainHand = context.mainHand
local deltaTime = context.deltaTime
local mainHandSwingProgress = context.mainHandSwingProgress
local swingMHand = context.swingMHand
local swingOHand = context.swingOHand
local swingProgress = context.swingProgress
local equipProgress = context.equipProgress
local mainHandSwitchEvent = context.mainHandSwitchEvent
local offHandSwitchEvent = context.offHandSwitchEvent

local l = (bl and 1) or -1

M:scale(matrices, 1.155, 1.155, 1.155)

function easeOutBack(t, back, speed)
    back = back or 1.70158
    speed = speed or 1.0
    t = math.min(math.max(t * speed, 0), 1)
    t = t - 1
    return (t * t * ((back + 1) * t + back) + 1)
end

function easeCustomSec(t)
	local t2 = t * t
	local t3 = t2 * t
	return 3 * t * (1 - t) * (1 - t) * 0.44 +
		3 * t2 * (1 - t) * 0.94 +
		t3
end

if not I:isEmpty(item) and not I:isBlock(item) and not I:isIn(item, Tags:getVanillaTag("spears")) then
	M:rotateX(matrices, -9)
	M:rotateZ(matrices, 8)
    M:moveY(matrices, -0.02)
    M:moveX(matrices, -0.1)
end


if not I:isEmpty(item) and not mainHand and not I:isBlock(item) and not I:isIn(item, Tags:getVanillaTag("spears")) then
	M:rotateY(matrices, 0)
	M:rotateZ(matrices, -15)
    M:moveZ(matrices, 0.05)
    M:moveY(matrices, 0.05)
    M:moveX(matrices, 0.15)
	M:scale(matrices, 1, 1, 1)
end

-- Buckets
if mainHand then
if I:isOf(item, Items:get("minecraft:axolotl_bucket")) or I:isOf(item, Items:get("minecraft:milk_bucket")) or I:isOf(item, Items:get("minecraft:salmon_bucket")) or I:isOf(item, Items:get("minecraft:cod_bucket")) or I:isOf(item, Items:get("minecraft:tropical_fish_bucket")) or I:isOf(item, Items:get("minecraft:tadpole_bucket")) or I:isOf(item, Items:get("minecraft:pufferfish_bucket")) or I:isOf(item, Items:get("minecraft:water_bucket")) or I:isOf(item, Items:get("minecraft:lava_bucket")) or I:isOf(item, Items:get("minecraft:powder_snow_bucket")) then
	M:moveY(matrices, 0.15)
	end
end

if not mainHand then
if I:isOf(item, Items:get("minecraft:axolotl_bucket")) or I:isOf(item, Items:get("minecraft:milk_bucket")) or I:isOf(item, Items:get("minecraft:salmon_bucket")) or I:isOf(item, Items:get("minecraft:cod_bucket")) or I:isOf(item, Items:get("minecraft:tropical_fish_bucket")) or I:isOf(item, Items:get("minecraft:tadpole_bucket")) or I:isOf(item, Items:get("minecraft:pufferfish_bucket")) or I:isOf(item, Items:get("minecraft:water_bucket")) or I:isOf(item, Items:get("minecraft:lava_bucket")) or I:isOf(item, Items:get("minecraft:powder_snow_bucket")) then
	M:moveY(matrices, 0.1)
	end
end
	
-- Spears

if I:isIn(item, Tags:getVanillaTag("spears")) and mainHand then
    M:moveZ(matrices, 0.25)
    M:moveX(matrices, -0.2)
    M:moveY(matrices, -0.02)
	M:rotateZ(matrices, 5)
	M:rotateY(matrices, -5)
end

if I:isIn(item, Tags:getVanillaTag("spears")) and not mainHand then
    M:moveZ(matrices, 0.25)
    M:moveX(matrices, 0.2)
    M:moveY(matrices, -0.02)
	M:rotateZ(matrices, -5)
	M:rotateY(matrices, 5)
end


-- Killa's Bow animation
local hand = context.hand

global.bowCount = 0;
global.bowCountO = 0;
global.bowCountSec = 0;
global.bowCountSecO = 0;
global.killas_bow = 0;
global.killas_bow_o = 0;
global.killas_bow_sec = 0;
global.killas_bow_sec_o = 0;
global.killas_bow_jitter = 0;
global.bow_phys = 0;
global.bow_phys_speed = 0;

local INTENSITY = 0.15
local GRAVITY = 0.05
local DAMPING = 0.8

bowCount = -0.1
bowCountO = -0.1

if P:isUsingItem(player) and P:getActiveHand(player) == hand and I:getUseAction(item) == "bow" then
	if mainHand then
		killas_bow = killas_bow + 0.075 * deltaTime * 30
		bow_phys_speed = bow_phys_speed + M:sin(Easings:easeInOutBack(killas_bow) * 3.14) * 6 * INTENSITY * deltaTime * 30
		killas_bow_jitter = killas_bow_jitter + 0.1 * deltaTime * 30
	else
		killas_bow_o = killas_bow_o + 0.075 * deltaTime * 30
		bow_phys_speed = bow_phys_speed + M:sin(Easings:easeInOutBack(killas_bow_o) * 3.14) * 6 * INTENSITY * deltaTime * 30
		killas_bow_jitter = killas_bow_jitter + 0.1 * deltaTime * 30
	end
else
	if mainHand then
		killas_bow = killas_bow - 0.06 * deltaTime * 30
	else
		killas_bow_o = killas_bow_o - 0.06 * deltaTime * 30
	end
end
killas_bow = M:clamp(killas_bow, 0, 1)
killas_bow_o = M:clamp(killas_bow_o, 0, 1)

if killas_bow == 0 then killas_bow_sec = 0 end
if killas_bow_o == 0 then killas_bow_sec_o = 0 end

if P:isUsingItem(player) and P:getActiveHand(player) == hand and I:getUseAction(item) == "bow" then
	if mainHand and killas_bow > 0.85 then
		killas_bow_sec = killas_bow_sec + 0.025 * deltaTime * 30
	elseif not mainHand and killas_bow_o > 0.85 then
		killas_bow_sec_o = killas_bow_sec_o + 0.025 * deltaTime * 30
	end
else
	if mainHand then
		killas_bow_sec = killas_bow_sec - 0.07 * deltaTime * 30
	else
		killas_bow_sec_o = killas_bow_sec_o - 0.07 * deltaTime * 30  -- fix: era killas_bow_o
	end
end
killas_bow_sec = M:clamp(killas_bow_sec, 0, 1)
killas_bow_sec_o = M:clamp(killas_bow_sec_o, 0, 1)

bow_phys_speed = bow_phys_speed - GRAVITY * bow_phys * deltaTime * 30
bow_phys_speed = bow_phys_speed * M:pow(DAMPING, deltaTime * 30)
bow_phys = bow_phys + bow_phys_speed * deltaTime * 30

local kb = Easings:easeInOutBack(killas_bow)
local kbs = Easings:easeOutBack(killas_bow_sec)
if mainHand then
	M:moveX(matrices, -0.5 * kb * l)
	M:moveY(matrices, -0.45 * kb)
	M:moveZ(matrices, -0.07 * kb)
	M:moveZ(matrices, -0.07 * kbs)
	M:rotateY(matrices, 6 * kb * l)
	M:rotateX(matrices, 10 * M:sin(kb * 3.14))
	M:rotateZ(matrices, 60 * kb * l)
	M:rotateX(matrices, 10 * M:sin(kb * 3.14))
	M:rotateX(matrices, -10 * kb)
else
	M:moveX(matrices, 0.85 * kb * l)
	M:moveZ(matrices, -1.5 * kb)
	M:moveZ(matrices, 0.4 * kbs)
	M:moveY(matrices, -0.3 * kb)
	M:rotateX(matrices, -55 * kb)
	M:rotateY(matrices, 110 * kb * l)
	M:rotateY(matrices, 10 * kbs * l)
end
M:moveZ(matrices, 0.004 * M:sin(killas_bow_jitter * 10) * kbs)

kb = Easings:easeInOutBack(killas_bow_o)
kbs = Easings:easeOutBack(killas_bow_sec_o)
if not mainHand then
	M:moveX(matrices, -0.5 * kb * l)
	M:moveY(matrices, -0.45 * kb)
	M:moveZ(matrices, -0.07 * kb)
	M:moveZ(matrices, -0.07 * kbs)
	M:rotateY(matrices, 6 * kb * l)
	M:rotateX(matrices, 10 * M:sin(kb * 3.14))
	M:rotateZ(matrices, 60 * kb * l)
	M:rotateX(matrices, 10 * M:sin(kb * 3.14))
	M:rotateX(matrices, -10 * kb)
else
	M:moveX(matrices, 0.85 * kb * l)
	M:moveZ(matrices, -1.5 * kb)
	M:moveZ(matrices, 0.4 * kbs)
	M:moveY(matrices, -0.3 * kb)
	M:rotateX(matrices, -55 * kb)
	M:rotateY(matrices, 110 * kb * l)
	M:rotateY(matrices, 10 * kbs * l)
end

if P:isUsingItem(player) and P:getActiveHand(player) == hand and I:getUseAction(item) == "bow" then
	M:rotateX(matrices, bow_phys)
	M:rotateY(matrices, -bow_phys * l)
end

M:moveZ(matrices, 0.004 * M:sin(killas_bow_jitter * 10) * kbs)

if I:getUseAction(item) == "bow" then
	M:rotateY(matrices, -15 * l)
end

-- HMI Tweaked Swimming 1.2
global.swimCounter = 0.0;
global.tweakedSwimCounter = 0.0;
global.submergedSmoother = 0.0;
global.wasSubmerged = false;

function easeOutBounce(t)
	if t < 1 / 2.75 then
		return 7.5625 * t * t
	elseif t < 2 / 2.75 then
		t = t - 1.5 / 2.75
		return 7.5625 * t * t + 0.75
	elseif t < 2.5 / 2.75 then
		t = t - 2.25 / 2.75
		return 7.5625 * t * t + 0.9375
	else
		t = t - 2.625 / 2.75
		return 7.5625 * t * t + 0.984375
	end
end

local isSubmergedNow = P:isSubmergedInWater(context.player) and not P:isUsingItem(context.player)

if isSubmergedNow and not wasSubmerged and (water_fall_d or 0) < 0.1 then
	tweakedSwimCounter = 0.0
	swimCounter = 0.0
end
wasSubmerged = isSubmergedNow

if isSubmergedNow then
	tweakedSwimCounter = tweakedSwimCounter + (P:getSpeed(context.player) ^ 1.2) * context.deltaTime * 30
	swimCounter = tweakedSwimCounter
	submergedSmoother = submergedSmoother + 0.05 * context.deltaTime * 30
else
	submergedSmoother = submergedSmoother - 0.05 * context.deltaTime * 30
end
submergedSmoother = M:clamp(submergedSmoother, 0, 1)

local easedSmoother = easeOutBounce(submergedSmoother) * M:clamp(1 - (water_fall_d or 0) * 2, 0, 1)

M:rotateX(context.matrices, -10 * easedSmoother, 0.3 * l, -0.4, 0)

if I:isEmpty(context.item) then
	M:rotateX(context.matrices, 5 * M:cos(swimCounter * 0.30) * easedSmoother, 0.3 * l, -0.4, 0)
end

M:rotateY(context.matrices, -23 * l * M:cos(swimCounter * 0.30) * easedSmoother, 0.3 * l, -0.4, 0)
M:rotateZ(context.matrices, -35 * l * M:sin(swimCounter * 0.30) * easedSmoother, 0.3 * l, -0.4, 0)

-- Diving__HMI__5.1
local l = context.bl and 1 or -1

global.offhand = 0;
global.fall = 0;
global.water_fall_d = 0;
global.jiggle_d = 0;
global.wfd_vel = 0;
global.rKeyPrev = false;
global.rKeyTimer = 0;
global.rDoubleTap = false;
global.air_time = 0;

local rKeyNow = KeyBindManager:isKeyPressed(32)
if rKeyNow and not rKeyPrev then
	if rKeyTimer > 0 then
		rDoubleTap = true
	else
		rKeyTimer = 12
	end
end
if not rKeyNow or P:isTouchingWater(context.player) then
	rDoubleTap = false
end
rKeyPrev = rKeyNow
rKeyTimer = math.max(0, rKeyTimer - context.deltaTime * 30)

if not P:isOnGround(context.player) then
	air_time = air_time + context.deltaTime
else
	air_time = 0
end

local hSpeed = math.sqrt(P:getXSpeed(context.player)^2 + P:getZSpeed(context.player)^2)

local wfd_target = 0
if not P:isOnGround(context.player) and rDoubleTap then
	wfd_target = 1
end
if not P:isOnGround(context.player) and hSpeed > 1.0 and air_time >= 1.0 then
	wfd_target = 1
end

local stiffness = 0.04
local damping = 0.72
wfd_vel = (wfd_vel + (wfd_target - water_fall_d) * stiffness * context.deltaTime * 30) * damping
water_fall_d = water_fall_d + wfd_vel
water_fall_d = M:clamp(water_fall_d, 0, 1.25)

jiggle_d = jiggle_d + P:getYSpeed(context.player) * context.deltaTime * 30

local wf = math.max(M:clamp(fall * 0.53, 0, 2), water_fall_d * water_fall_d) * (water_fall_d * water_fall_d * water_fall_d)

offhand = offhand - M:clamp(wf * 2, 0, 1)
	if I:isEmpty(context.item) then
		M:moveY(context.matrices, 0.46 * wf)
	else
		M:moveY(context.matrices, 0.18 * wf)
	end
	M:moveX(context.matrices, -0.1 * l * wf)
	M:moveX(context.matrices, 0.15 * l * M:clamp(wf, 0, 1))
	M:moveZ(context.matrices, -0.15 * wf)
	M:rotateY(context.matrices, 15 * l * wf, 0.3 * l, -0.4, 0)
	M:rotateX(context.matrices, -30 * wf, 0.3 * l, -0.4, 0)
	M:rotateZ(context.matrices, 0.5 * M:sin(jiggle_d * 0.6) * wf * l)
	M:rotateX(context.matrices, 0.5 * M:sin(jiggle_d * 0.6) * wf * l)
	local wfClamped = M:clamp(wf, 0, 1)
	M:scale(context.matrices, 1 - 0.07 * wfClamped, 1 - 0.07 * wfClamped, 1 + 0.015 * wf + 0.25 * wfClamped)


