function easeOutBack(t, back, speed)
    back = back or 1.70158
    speed = speed or 1.0
    t = math.min(math.max(t * speed, 0), 1)
    t = t - 1
    return (t * t * ((back + 1) * t + back) + 1)
end

function easeCustom(t)
    local t2 = t * t
    local t3 = t2 * t
    return 3 * t * (1 - t) * (1 - t) * 0.44 +
            3 * t2 * (1 - t) * 1 +
            t3
end

function easeCustomSec(t)
	local t2 = t * t
	local t3 = t2 * t
	return 3 * t * (1 - t) * (1 - t) * 0.44 +
		3 * t2 * (1 - t) * 0.94 +
		t3
end

local bl = context.bl
local item = context.item
local matrices = context.matrices
local player = context.player
local mainHand = context.mainHand
local deltaTime = context.deltaTime
local mainHandSwingProgress = context.mainHandSwingProgress
local swingMHand = context.swingMHand
local swingOHand = context.swingOHand
local swingProgress = context.swingProgress
local equipProgress = context.equipProgress
local mainHandSwitchEvent = context.mainHandSwitchEvent
local offHandSwitchEvent = context.offHandSwitchEvent

local l = (bl and 1) or -1

if not I:isEmpty(item) and not I:isBlock(item) and mainHand then
	if not I:isIn(item, Tags:getVanillaTag("swords")) and not I:isIn(item, Tags:getVanillaTag("shovels")) and not I:isIn(item, Tags:getVanillaTag("pickaxes")) and not I:isIn(item, Tags:getVanillaTag("axes")) and not I:isIn(item, Tags:getVanillaTag("hoes")) and not I:isOf(item, Items:get("minecraft:mace")) and not I:isOf(item, Items:get("minecraft:trident")) and not I:isOf(item, Items:get("minecraft:stick")) and not I:isOf(item, Items:get("minecraft:bamboo")) and not I:isOf(item, Items:get("minecraft:bone")) then
	M:rotateZ(matrices, -7)
	M:rotateY(matrices, 5)
	M:moveX(matrices, 0.073)
	M:moveZ(matrices, -0.1)
	end
end

if not I:isEmpty(item) and not I:isBlock(item) and not mainHand then
	if not I:isIn(item, Tags:getVanillaTag("swords")) and not I:isIn(item, Tags:getVanillaTag("shovels")) and not I:isIn(item, Tags:getVanillaTag("pickaxes")) and not I:isIn(item, Tags:getVanillaTag("axes")) and not I:isIn(item, Tags:getVanillaTag("hoes")) and not I:isOf(item, Items:get("minecraft:mace")) and not I:isOf(item, Items:get("minecraft:trident")) and not I:isOf(item, Items:get("minecraft:stick")) and not I:isOf(item, Items:get("minecraft:bamboo")) and not I:isOf(item, Items:get("minecraft:bone")) then
	M:rotateZ(matrices, 7)
	M:rotateY(matrices, -5)
	M:moveX(matrices, -0.073)
	M:moveZ(matrices, -0.1)
	end
end

if mainHand then
	if I:isIn(item, Tags:getVanillaTag("swords")) or I:isIn(item, Tags:getVanillaTag("pickaxes")) or I:isIn(item, Tags:getVanillaTag("axes")) or I:isIn(item, Tags:getVanillaTag("hoes")) or I:isOf(item, Items:get("minecraft:stick")) then
	M:rotateZ(matrices, -2)
	M:moveX(matrices, 0.025)
	M:moveY(matrices, -0.035)
	M:moveZ(matrices, -0.06)
	M:rotateY(matrices, -5.5)
	M:rotateX(matrices, 0)
	M:scale(matrices, 1.2, 1.2, 1.2)
	end
end

if not mainHand then
	if I:isIn(item, Tags:getVanillaTag("swords")) or I:isIn(item, Tags:getVanillaTag("pickaxes")) or I:isIn(item, Tags:getVanillaTag("axes")) or I:isIn(item, Tags:getVanillaTag("hoes")) or I:isOf(item, Items:get("minecraft:stick")) then
	M:rotateZ(matrices, 0)
	M:moveX(matrices, -0.025)
	M:moveY(matrices, -0.028)
	M:moveZ(matrices, -0.05)
	M:rotateY(matrices, 8)
	M:rotateX(matrices, 5)
	M:scale(matrices, 1.1, 1.1, 1.1)
	end
end


-- Fixes

if I:isOf(item, Items:get("minecraft:mace")) then
	M:rotateZ(matrices, 0)
	M:rotateY(matrices, -5.5)
	M:rotateX(matrices, -5)
	M:moveX(matrices, 0)
	M:moveY(matrices, 0.05)
	M:moveZ(matrices, -0.05)
	local maceSwingOverall = M:sin(swingProgress * 3.14)
	M:scale(matrices, 1.1 * (1 - 0.11 * maceSwingOverall), 1.1 * (1 - 0.11 * maceSwingOverall), 1.1 * (1 + 0.22 * maceSwingOverall))
end

if mainHand and I:isIn(item, Tags:getVanillaTag("shovels")) then
	M:moveX(matrices, -0.02)
	M:moveZ(matrices, -0.08)
	M:moveY(matrices, -0.08)
	M:rotateX(matrices, 10)
	M:rotateY(matrices, 4)
	M:rotateZ(matrices, -4)
	M:scale(matrices, 1.2, 1.2, 1.2)
end

if not mainHand and I:isIn(item, Tags:getVanillaTag("shovels")) then
	M:moveX(matrices, 0.02)
	M:moveY(matrices, 0.08)
	M:rotateX(matrices, 15)
	M:moveZ(matrices, 0.06)
	M:rotateY(matrices, -4)
	M:scale(matrices, 1.2, 1.2, 1.2)
end

if I:isOf(item, Items:get("minecraft:trident")) and mainHand then
	M:moveZ(matrices, 0.1)
	M:moveX(matrices, -0.1)
	else if I:isOf(item, Items:get("minecraft:trident")) then
	M:moveZ(matrices, 0.1)
	M:moveX(matrices, 0.1)
	end
end

if I:isOf(item, Items:get("minecraft:mace")) and mainHand then
	M:moveX(matrices, 0.05)
	else if I:isOf(item, Items:get("minecraft:mace")) then
	M:moveX(matrices, -0.05)
	end
end

-- Buckets
if mainHand then
if I:isOf(item, Items:get("minecraft:axolotl_bucket")) or I:isOf(item, Items:get("minecraft:milk_bucket")) or I:isOf(item, Items:get("minecraft:salmon_bucket")) or I:isOf(item, Items:get("minecraft:cod_bucket")) or I:isOf(item, Items:get("minecraft:tropical_fish_bucket")) or I:isOf(item, Items:get("minecraft:tadpole_bucket")) or I:isOf(item, Items:get("minecraft:pufferfish_bucket")) or I:isOf(item, Items:get("minecraft:water_bucket")) or I:isOf(item, Items:get("minecraft:lava_bucket")) then
		M:moveX(matrices, -0.2)
		M:moveZ(matrices, 0.029)
		M:moveY(matrices, 0.15)
		M:rotateY(matrices, -12)
		M:rotateZ(matrices, -4) 
		end
end

if not mainHand then
if I:isOf(item, Items:get("minecraft:axolotl_bucket")) or I:isOf(item, Items:get("minecraft:milk_bucket")) or I:isOf(item, Items:get("minecraft:salmon_bucket")) or I:isOf(item, Items:get("minecraft:cod_bucket")) or I:isOf(item, Items:get("minecraft:tropical_fish_bucket")) or I:isOf(item, Items:get("minecraft:tadpole_bucket")) or I:isOf(item, Items:get("minecraft:pufferfish_bucket")) or I:isOf(item, Items:get("minecraft:water_bucket")) or I:isOf(item, Items:get("minecraft:lava_bucket")) then
		M:moveX(matrices, 0.1)
		M:moveZ(matrices, 0.09)
		M:moveY(matrices, 0.17)
		M:rotateY(matrices, 12)
		M:rotateZ(matrices, -4) 
	end
end

if mainHand and I:isOf(item, Items:get("minecraft:powder_snow_bucket")) then
		M:moveY(matrices, 0.23)
		M:moveZ(matrices, -0.11)
		M:moveX(matrices, -0.1)
		M:rotateZ(matrices, -12)
		M:rotateX(matrices, -4) 
	else if I:isOf(item, Items:get("minecraft:powder_snow_bucket")) then
		M:moveY(matrices, 0.26)
		M:moveZ(matrices, -0.06)
		M:moveX(matrices, 0.06)
		M:rotateZ(matrices, 8)
		M:rotateX(matrices, -4) 
	end
end

-- Spears

if I:isIn(item, Tags:getVanillaTag("spears")) and mainHand then
	M:moveZ(matrices, 0.060)
	M:moveY(matrices, -0.080)
	M:moveX(matrices, -0.060)
	M:rotateY(matrices, 0)
	M:rotateX(matrices, -4.5)
	M:rotateZ(matrices, 10)
end

if I:isIn(item, Tags:getVanillaTag("spears")) and not mainHand then
	M:moveZ(matrices, 0.2)
	M:moveY(matrices, -0.05)
	M:moveX(matrices, 0.1)
	M:rotateY(matrices, 0)
	M:rotateX(matrices, -4.5)
	M:rotateZ(matrices, -10)
end

-- Killa's Bow item state
global.killas_bow_sec = 0;
global.killas_bow_sec_o = 0;
if I:getUseAction(item) == "bow" then
	local bc = mainHand
		and Easings:easeOutBack(killas_bow_sec)
		or  Easings:easeOutBack(killas_bow_sec_o)

	if bc < 0.1 then
		usingItem:put("minecraft:bow", false)
	else
		usingItem:put("minecraft:bow", true)
	end

	useDuration:put("minecraft:bow", Easings:cubicEase(bc) * 20)
end